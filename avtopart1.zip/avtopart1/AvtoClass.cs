﻿using System;

class Car
{
    private int fuelTank;
    private double mileage;
    private int fuelConsumptionPer100Km;
    private double speed;
    private int fuelTankCapacity;

    public Car(int fuelTankCapacity)
    {
        this.fuelTankCapacity = fuelTankCapacity;
        fuelTank = fuelTankCapacity;
    }

    public void FillTank()
    {
        Console.WriteLine($"Текущий уровень топлива: {fuelTank} литров.");
        Console.WriteLine("Введите количество топлива для заправки:");

        if (int.TryParse(Console.ReadLine(), out int fuel))
        {
            if (fuel >= 0)
            {
                int potentialFuelLevel = fuelTank + fuel;

                if (potentialFuelLevel <= fuelTankCapacity)
                {
                    fuelTank = potentialFuelLevel;
                    Console.WriteLine($"В бак залито {fuel} литров топлива. Общий объем бака: {fuelTank} литров.");
                }
                else
                {
                    fuelTank = fuelTankCapacity;
                    Console.WriteLine($"Бак заполнен на {fuelTank} литров.");
                }
            }
            else
            {
                Console.WriteLine("Недопустимый ввод. Введите неотрицательное значение.");
            }
        }
        else
        {
            Console.WriteLine("Неверный ввод. Не удалось заправить бак. Введите корректное число.");
            Console.ReadLine(); 
        }
    }

    public void SetFuelConsumption()
    {
        Console.WriteLine("Введите расход топлива на 100 км:");
        if (int.TryParse(Console.ReadLine(), out int consumption))
        {
            if (consumption >= 0)
            {
                fuelConsumptionPer100Km = consumption;
                Console.WriteLine($"Расход топлива установлен на {consumption} литров на 100 км.");
            }
            else
            {
                Console.WriteLine("Недопустимый ввод. Введите неотрицательное значение.");
            }
        }
        else
        {
            Console.WriteLine("Неверный ввод. Не удалось установить расход топлива.");
        }
    }

    public void SetSpeed()
    {
        Console.WriteLine("Введите начальную скорость:");
        if (double.TryParse(Console.ReadLine(), out double initialSpeed))
        {
            if (initialSpeed >= 0)
            {
                speed = initialSpeed;
                Console.WriteLine($"Начальная скорость {initialSpeed} км/ч.");
            }
            else
            {
                Console.WriteLine("Неверный ввод. Введите корректное значение.");
            }
        }
        else
        {
            Console.WriteLine("Неверный ввод.");
        }
    }

    public void Accelerate()
    {
        Console.WriteLine("Введите скорость ускорения:");
        if (double.TryParse(Console.ReadLine(), out double acceleration))
        {
            if (acceleration >= 0)
            {
                speed += acceleration;
                Console.WriteLine($"Автомобиль разгоняется. Текущая скорость: {speed} км/ч.");
            }
            else
            {
                Console.WriteLine("Неверный ввод. Введите неотрицательное значение.");
            }
        }
        else
        {
            Console.WriteLine("Неверный ввод.");
        }
    }

    public void Brake()
    {
        Console.WriteLine("Введите скорость торможения:");
        if (double.TryParse(Console.ReadLine(), out double braking))
        {
            if (braking >= 0 && braking <= speed)
            {
                speed -= braking;
                Console.WriteLine($"Автомобиль тормозит. Текущая скорость: {speed} км/ч.");
            }
            else
            {
                Console.WriteLine("Неверный ввод");
            }
        }
        else
        {
            Console.WriteLine("Неверный ввод");
        }
    }

    private int CalculateDistance()
    {
        return new Random().Next(1, 101); 
    }

    public void Drive()
    {
        Console.WriteLine("Перед началом работы установите начальную скорость:");
        SetSpeed();

        while (true)
        {
            double maxDistance = (double)fuelTank / (fuelConsumptionPer100Km / 100.0);
            int distance = CalculateDistance();

            if (distance <= maxDistance)
            {
                double fuelConsumed = (fuelConsumptionPer100Km / 100.0) * distance;

                Console.WriteLine($"Проехать {distance} км при {speed} км/ч.");
                mileage += distance;
                fuelTank = Math.Max(0, fuelTank - (int)fuelConsumed);

                Console.WriteLine($"Остаток топлива: {fuelTank} литров.");

                Console.WriteLine("Выберите действие:");
                Console.WriteLine("1. Ускорение");
                Console.WriteLine("2. Торможение");
                Console.WriteLine("3. Продолжить движение");
                Console.WriteLine("4. Выход");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            Accelerate();
                            break;
                        case 2:
                            Brake();
                            break;
                        case 3:
                            continue;
                        case 4:
                            return;
                        default:
                            Console.WriteLine("Неверный выбор. Продолжаем движение.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Неверный выбор. Продолжаем движение.");
                }
            }
            else
            {
                Console.WriteLine($"Недостаточно топлива для преодоления расстояния. Можно проехать {{maxDistance}} км.");
                AskForRefuel();
                return; 
            }
        }
    }

    private void AskForRefuel()
    {
        Console.WriteLine("Недостаточно топлива. Вы хотите заправиться? (y/n)");
        string response = Console.ReadLine();

        if (response.ToLower() == "y")
        {
            FillTank();
        }
        else
        {
            Console.WriteLine("В заправке отказано.");
        }
    }

    public double GetTotalMileage()
    {
        return mileage;
    }
}

