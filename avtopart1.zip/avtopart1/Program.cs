﻿class Program
{
    static void Main()
    {
        Console.WriteLine("Введите объем бака:");
        if (int.TryParse(Console.ReadLine(), out int initialFuel))
        {
            Car myCar = new Car(initialFuel);

            myCar.SetFuelConsumption();

            while (true)
            {
                Console.WriteLine("Выберите действие:");
                Console.WriteLine("1. Начальная скорость");
                Console.WriteLine("2. Ускорение");
                Console.WriteLine("3. Торможение");
                Console.WriteLine("4. Заправка");
                Console.WriteLine("5. Начать поездку");
                Console.WriteLine("6. выход");

                if (int.TryParse(Console.ReadLine(), out int choice))
                {
                    switch (choice)
                    {
                        case 1:
                            myCar.SetSpeed();
                            break;
                        case 2:
                            myCar.Accelerate();
                            break;
                        case 3:
                            myCar.Brake();
                            break;
                        case 4:
                            myCar.FillTank();
                            break;
                        case 5:
                            myCar.Drive();
                            break;
                        case 6:
                            double totalMileage = myCar.GetTotalMileage();
                            Console.WriteLine($"Общий пробег: {totalMileage} км. Выход из программы.");
                            return;
                        default:
                            Console.WriteLine("Неверный выбор. Пожалуйста, выберите еще раз.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Неверный выбор. Пожалуйста, выберите еще раз.");
                }
            }
        }
        else
        {
            Console.WriteLine("Недопустимый ввод. Программа завершена.");
        }
    }
}